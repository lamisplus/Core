import React from 'react';

const EmptyPage = () => {
	return(
		<>
			hi
		</>
	)
}
export default EmptyPage;