export const initialfieldState_userRegistration = {
    firstName: '',
    lastName: '',
    username: '',
    email: '',
    phone: '',
    role: '',
    designation:'',
    gender: '',
    dateOfBirth: new Date(),
    password: '',
    adminRegistration: true,
    details:{}

  }
  