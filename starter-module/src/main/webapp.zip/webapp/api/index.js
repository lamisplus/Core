

//Online Server
//export const url =  'http://www.lamisplus.org/base-module/api/';

//Local Server
export const url =  'http://localhost:8282/api/v1/';
//export const url = '/api/v1/'


